//
//  HomeTableCell.swift
//  AnjanTask
//
//  Created by Venkatesh on 27/08/24.
//

import UIKit

class HomeTableCell: UITableViewCell {
    
    @IBOutlet weak var movieImgV: UIImageView!
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var descLbl: UILabel!
    @IBOutlet weak var releasedDateLbl: UILabel!
    
    @IBOutlet weak var favouriteBtn: UIButton!
    @IBOutlet weak var favouriteImg: UIImageView!



    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
