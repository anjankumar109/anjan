//
//  ViewController.swift
//  AnjanTask
//
//  Created by Venkatesh on 27/08/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.perform(#selector(callback), with: nil, afterDelay: 2.0)

        // Do any additional setup after loading the view.
    }
    
    @objc func callback() {
        print("done")
        let detailVc = self.storyboard?.instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
        self.navigationController?.pushViewController(detailVc, animated: true)
    }

}

