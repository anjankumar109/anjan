//
//  MoviesModel.swift
//  AnjanTask
//
//  Created by Venkatesh on 27/08/24.
//

import Foundation

struct MoviesModel : Decodable {
    let Title : String
   // let Year : Int?
    let Director : String?
    let Language : String?
    let Poster : String?
    let Released : String?
    
    let Actors : String?
    let Country : String?
    let Awards : String?


}

