//
//  HomeViewController.swift
//  AnjanTask
//
//  Created by Venkatesh on 27/08/24.
//

import UIKit

class HomeViewController: UIViewController,UISearchBarDelegate {
    
    var moviesArray = [MoviesModel]()
    
    var isSearching : Bool = false

    var movieSearchListArrData = [MoviesModel]()

    
    var favouritesArray = [Int]()

    @IBOutlet weak var searchbar: UISearchBar!
    

    @IBOutlet weak var moviesTableV: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        searchbar.delegate = self
        
        moviesTableV.register(UINib(nibName: "HomeTableCell", bundle: nil), forCellReuseIdentifier: "HomeTableCell")
        
        
        loadMoviesData()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    func loadMoviesData(){
        let apiUrlString = "https://www.omdbapi.com/?i=tt3896198&apikey=2d673b9a"
        let apiUrl = URL(string: apiUrlString)
        var apiUrlRequest = URLRequest(url: apiUrl!)
        
        apiUrlRequest.httpMethod = "GET"
        
        let task = URLSession.shared.dataTask(with: apiUrlRequest) {(data,response,error) in
            if let apiError = error {
                print("error is \(apiError.localizedDescription)")
            }
            else{
                let jsonData = try? JSONSerialization.jsonObject(with: data!, options: .allowFragments)
                print(jsonData)
                
                let responseData = try? JSONDecoder().decode(MoviesModel.self, from: data!)
                print(responseData)
                
                self.moviesArray.append(responseData!)
                print("movies array is \(self.moviesArray)")
                
                if Constant.shared.favouritesArray.isEmpty {
                    for i in self.moviesArray{
                        Constant.shared.favouritesArray.append(0)
                    }
                }
                else{
                    let defaults = UserDefaults.standard
                    Constant.shared.favouritesArray = defaults.object(forKey: "favourites") as? [Int] ?? [Int]()
                }
                
                DispatchQueue.main.async {
                    self.moviesTableV.reloadData()
                }
            }
        }
        task.resume()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.view.endEditing(true)
        self.navigationController?.isNavigationBarHidden = true
    }
    override func viewWillDisappear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = false

    }

}

extension HomeViewController : UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if isSearching {
                   return movieSearchListArrData.count
               }
                   
        else{
            return moviesArray.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellIdentifier="HomeTableCell"
        
    let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? HomeTableCell
        
        if isSearching {
            
            DispatchQueue.main.async {
                cell?.titleLbl.text = self.movieSearchListArrData[indexPath.row].Title
                cell?.descLbl.text = "Director is \(self.movieSearchListArrData[indexPath.row].Director ?? "")"
                cell?.releasedDateLbl.text = "Released on \(self.movieSearchListArrData[indexPath.row].Released ?? "")"
                
                let imageString = self.movieSearchListArrData[indexPath.row].Poster ?? ""
                let imageUrl = URL(string: imageString)
                let imageData = try? Data(contentsOf: imageUrl!)
                cell?.movieImgV.image = UIImage.init(data: imageData!)
            }
            
            
            cell?.favouriteBtn.tag = indexPath.row
            cell?.favouriteBtn.addTarget(self, action:#selector(favouriteBtnClicked), for:.touchUpInside)
            
            if Constant.shared.favouritesArray[indexPath.row] == 0 {
                cell?.favouriteImg.image = UIImage(named: "favouriteempty")
            }
            else{
                cell?.favouriteImg.image = UIImage(named: "favouritefill")
            }
        }
        else{
            
            DispatchQueue.main.async {
                cell?.titleLbl.text = self.moviesArray[indexPath.row].Title
                cell?.descLbl.text = "Director is \(self.moviesArray[indexPath.row].Director ?? "")"
                cell?.releasedDateLbl.text = "Released on \(self.moviesArray[indexPath.row].Released ?? "")"
                
                let imageString = self.moviesArray[indexPath.row].Poster ?? ""
                let imageUrl = URL(string: imageString)
                let imageData = try? Data(contentsOf: imageUrl!)
                cell?.movieImgV.image = UIImage.init(data: imageData!)
            }
            
            
            cell?.favouriteBtn.tag = indexPath.row
            cell?.favouriteBtn.addTarget(self, action:#selector(favouriteBtnClicked), for:.touchUpInside)
            
            if Constant.shared.favouritesArray[indexPath.row] == 0 {
                cell?.favouriteImg.image = UIImage(named: "favouriteempty")
            }
            else{
                cell?.favouriteImg.image = UIImage(named: "favouritefill")
            }
        }



    cell?.selectionStyle = .none
        return cell!
    }
    
    @objc func favouriteBtnClicked(_ sender: AnyObject) {
        let point = sender.convert(CGPoint.zero, to: self.moviesTableV as UIView)
        let indexPath: IndexPath! = self.moviesTableV.indexPathForRow(at: point)

        print("indexPath.row is = \(indexPath.row) && indexPath.section is = \(indexPath.section)")
        
        let indexPath2 = IndexPath.init(row: indexPath.row, section: indexPath.section)
        let cell = moviesTableV.cellForRow(at: indexPath2) as! HomeTableCell
        if Constant.shared.favouritesArray[sender.tag] == 0 {
            Constant.shared.favouritesArray[sender.tag] = 1
            cell.favouriteImg.image = UIImage(named: "favouritefill")
        }
        else{
            Constant.shared.favouritesArray[sender.tag] = 0
            cell.favouriteImg.image = UIImage(named: "favouriteempty")

        }
        print(Constant.shared.favouritesArray)
        
        let defaults = UserDefaults.standard
        defaults.set(Constant.shared.favouritesArray, forKey: "favourites")
        
        DispatchQueue.main.async {
            self.moviesTableV.reloadData()
        }
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 140
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if isSearching {
            let detailVc = self.storyboard?.instantiateViewController(withIdentifier: "MoviesDetailViewController") as! MoviesDetailViewController
            detailVc.movieDetails = movieSearchListArrData[indexPath.row]
            detailVc.favouriteValue = Constant.shared.favouritesArray[indexPath.row]
            self.navigationController?.pushViewController(detailVc, animated: true)
        }
        else{
            let detailVc = self.storyboard?.instantiateViewController(withIdentifier: "MoviesDetailViewController") as! MoviesDetailViewController
            detailVc.movieDetails = moviesArray[indexPath.row]
            detailVc.favouriteValue = Constant.shared.favouritesArray[indexPath.row]
            self.navigationController?.pushViewController(detailVc, animated: true)
        }
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
           guard !searchText.isEmpty else {
               isSearching = false
               moviesTableV.reloadData()
               return
           }
           isSearching = true
           
           movieSearchListArrData = moviesArray.filter({ (moviesArray) -> Bool in
               moviesArray.Title.lowercased().contains(searchText.lowercased())
           })
           
        moviesTableV.reloadData()
       }
}
