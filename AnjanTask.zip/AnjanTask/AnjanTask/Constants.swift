//
//  Constants.swift
//  Lupin
//
//  Created by apple on 12/15/19.
//  Copyright © 2019 apple. All rights reserved.
//

import Foundation
import UIKit


enum Cookie: String {
    
    case favouritesArray = "favouritesArray"
   
}

class Constant {
    
    static var shared : Constant = Constant()
    
    var favouritesArray = [Int]()
    
    
    //Hide Constant instance Creation because it is Singleton Class
    
    func setLocalObject( value: Any?, forKey key: Cookie)
    {
        UserDefaults.standard.setValue(value, forKey: key.rawValue)
    }
    
    func getLocalObject(forKey key: Cookie) -> Any?
    {
        return UserDefaults.standard.value(forKey: key.rawValue)
    }
}







