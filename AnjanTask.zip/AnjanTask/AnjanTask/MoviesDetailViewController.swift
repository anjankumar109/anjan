//
//  MoviesDetailViewController.swift
//  AnjanTask
//
//  Created by Venkatesh on 27/08/24.
//

import UIKit

class MoviesDetailViewController: UIViewController {
    
    var movieDetails : MoviesModel?
    
    var favouriteValue : Int?


    
    @IBOutlet weak var movieImgV: UIImageView!
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var descLbl: UILabel!
    @IBOutlet weak var releasedDateLbl: UILabel!
    
    @IBOutlet weak var actorsLbl: UILabel!
    @IBOutlet weak var countryLbl: UILabel!
    @IBOutlet weak var awardsLbl: UILabel!

    @IBOutlet weak var favouriteBtn: UIButton!
    @IBOutlet weak var favouriteImg: UIImageView!

    override func viewDidLoad() {
        super.viewDidLoad()

        DispatchQueue.main.async {
            self.titleLbl.text = self.movieDetails?.Title
            self.descLbl.text = "Director is \(self.movieDetails?.Director ?? "")"
            self.releasedDateLbl.text = "Released on \(self.movieDetails?.Released ?? "")"
            
            let imageString = self.movieDetails?.Poster ?? ""
            let imageUrl = URL(string: imageString)
            let imageData = try? Data(contentsOf: imageUrl!)
            self.movieImgV.image = UIImage.init(data: imageData!)
            
            self.actorsLbl.text = "Actors \(self.movieDetails?.Actors ?? "")"
            self.countryLbl.text = "Country is \(self.movieDetails?.Country ?? "")"
            self.awardsLbl.text = "Awards are \(self.movieDetails?.Awards ?? "")"
            
            if self.favouriteValue == 0 {
                self.favouriteImg.image = UIImage(named: "favouriteempty")
            }
            else{
                self.favouriteImg.image = UIImage(named: "favouritefill")
            }
        }
        
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
